package prac;

public class Company
{
	Dept dept;
	Employee employee;
	String dName, eName;

	public String getEmployee() {
		return eName;
	}

	public void setEmployee(String eName) {
		this.eName = eName;
	}

	public String getDept() {
		return dName;
	}

	public void setDept(String dName) {
		this.dName = dName;
	}

	public static void main(String[] args)
	{
		Company com=new Company();
		Dept d1=new Dept();
		
		com.setDept("marketing");
		String c=com.getDept();
		d1.descDept(c, 9887);
	
		
		Dept d2=new Dept();
		
		com.setDept("accounts");
		String c1=com.getDept();
		d2.descDept(c1, 7766);
		
		Dept d3=new Dept();
		
		com.setDept("database");
		String c2=com.getDept();
		d2.descDept(c2, 7366);
		
		Dept d4=new Dept();
		
		com.setDept("develops");
		String c3=com.getDept();
		d2.descDept(c3, 7888);
		
		
		Employee e1=new Employee();
		com.setEmployee("Mona");
		String m1=com.getEmployee();
		e1.descEmp(m1, 8765);
		
	}

}
