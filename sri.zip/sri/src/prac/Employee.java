package prac;

public class Employee
{
	int Id;
    String address;
	public void addEmp()
	{
		Id= 201;
		address= "bang";
	}
	public void printEmp(int salary)
	{
		System.out.println("the id is:"+Id);
		System.out.println("the address is:"+address);
		System.out.println("the salary is:"+salary);
	}
	public void descEmp(String name, int phnmbr)
	{
		System.out.println("emp name is:"+name);
		System.out.println("emp number is:"+phnmbr);
		
	}

	public static void main(String[] args)
	{
		Employee emp=new Employee();
		emp.addEmp();
		emp.printEmp(200000);
		emp.descEmp("Mohan", 988);
	}

}
