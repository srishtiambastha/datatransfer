package prac;

public class Dept 
{
	String deptadd;
	public void addDept()
	{
		deptadd="mvm";
	}
	public void printDept(int Id)
	{
		System.out.println("the dept address is:"+deptadd);
		System.out.println("the id is:"+Id);
	}
	public void descDept(String name,int phnmbr)
	{
		System.out.println("emp name is:"+name);
		System.out.println("emp number is:"+phnmbr);
		
	}

	public static void main(String[] args) 
	{
		Dept dep=new Dept();
		dep.addDept();
		dep.printDept(300);
		dep.descDept("HR", 88899);
		
		

	}

}
